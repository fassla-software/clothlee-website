INSERT INTO `business_settings` (`id`, `type`, `value`, `lang`, `created_at`, `updated_at`) VALUES (NULL, 'khalti_sandbox', '1', NULL, current_timestamp(), current_timestamp());

COMMIT;
